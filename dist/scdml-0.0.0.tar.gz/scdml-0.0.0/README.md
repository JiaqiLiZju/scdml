## main function

1. train & validate

2. inference 

3. interpret

4. scanpy api

### supervised annotation

    generate models for supervised annotation
    inference on held out datasets

1. 数据集 / label

2. 人 / 鼠 / 鱼 / EC_atlas

3. 10X / Micro-well

### fine-tuning

1. fine tune with pretrain models

### feature importance

1. find markers

